package new_expt;

public class InvaliPolicyException extends Exception {
InvaliPolicyException(){
	System.out.println("Exception is catched");
}

}
