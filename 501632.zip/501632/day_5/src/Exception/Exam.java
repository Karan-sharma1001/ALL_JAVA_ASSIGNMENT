package Exception;

public class Exam {

}
