package Exception;

public class Mgr extends Emp1 {
	int reportees;

}
