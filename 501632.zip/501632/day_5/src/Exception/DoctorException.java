package Exception;

public class DoctorException extends Exception {
	//Default constructor
	public DoctorException() {
		System.out.println("In DoctorException default constructor");
	}

}
