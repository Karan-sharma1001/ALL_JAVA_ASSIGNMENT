package Exception;

public class Emp1 {

	int id;
	int sal;
	String name;

	public Emp1() {
		super();
	}

	public void display() {
		
	}

}