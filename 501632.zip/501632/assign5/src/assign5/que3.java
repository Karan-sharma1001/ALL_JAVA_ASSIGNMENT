package assign5;

public class que3 {

	
	
	
}
