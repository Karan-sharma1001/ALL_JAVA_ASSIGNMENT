
public class Exc_Test extends Exception {

	public Exc_Test() {
		super();
				System.out.println("Enter correct value");
	}



}
