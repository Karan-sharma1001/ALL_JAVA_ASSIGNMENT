
public class TestArithmetic {
	public static void main(String[] args) {
		
	
Arithematic a=new Arithematic();
		System.out.println(a.addition(2,3));
		System.out.println(a.addition(2,3,4));
		System.out.println(a.addition(2.77,3.54));
		System.out.println(a.addition(2,7.53));
		System.out.println(a.addition(2.3f,3.55f,3.7f));
}
}