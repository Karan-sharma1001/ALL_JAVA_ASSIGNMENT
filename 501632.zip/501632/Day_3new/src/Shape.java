
public interface Shape {
	public void draw( );
	public void rotate( );

}
