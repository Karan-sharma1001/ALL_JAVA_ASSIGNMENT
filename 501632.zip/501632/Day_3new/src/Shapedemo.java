import com.shape.*;
public class Shapedemo {
public static void main(String[] args) {
	Square s1=new Square();
	Rectangle r1=new Rectangle();
	System.out.println("Enter side length");
	s1.calcArea();
	s1.calcPeri();
	System.out.println("Rectnagle Length,Breadth");

}
}
