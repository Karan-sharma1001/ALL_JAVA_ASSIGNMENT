
public interface GeometryConstant {
 double PI = 3.142;
	
}
