
public class Testshape {
public static void main(String[] args) {
	Circle c=new Circle();
	Rectangle r= new Rectangle();
	c.draw();
	c.rotate();
	r.draw();
	r.rotate();
}
}
