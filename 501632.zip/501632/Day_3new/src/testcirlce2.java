
public class testcirlce2 {
public static void main(String[] args) {
	Circle2 c=new Circle2();
	System.out.println("Area is  "+c.calArea(3));
	System.out.println("Circumference is "+c.calCircumference(3));
}
}
