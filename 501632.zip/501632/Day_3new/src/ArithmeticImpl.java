
public class ArithmeticImpl extends Arithematic {

	@Override
	public int subtraction(int firstNo, int secondNo) {
		
		return(firstNo-secondNo);
	}

	@Override
	public int subtraction(int firstNo, int secondNo, int thirdNo) {
		// TODO Auto-generated method stub
		return(firstNo-secondNo-thirdNo);
	}


	public double subtraction(double firstNo, double secondNo) {
		// TODO Auto-generated method stub
		return(firstNo-secondNo);
	}

	@Override
	public double subtraction(int firstNo, double secondNo) {
		// TODO Auto-generated method stub
		return(firstNo-secondNo);
	}

	@Override
	public float subtraction(float firstNo, float secondNo, float thirdNo) {
		// TODO Auto-generated method stub
		return(firstNo-secondNo-thirdNo);
	}

}
