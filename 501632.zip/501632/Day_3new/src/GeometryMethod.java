
public interface GeometryMethod {
	double calArea ( double radius );
	double calCircumference ( double radius );

}
