
public class Testequal {
public static void main(String[] args) {
	
	
	
	
	
}
}
