package assign6;

public class Storage {
	Counter c1;
	int value;
	
	public void storeInt(int x) {
		value=x;
		  }
	 public int getIntcounter() {
		 int z=c1.getA();
		return z;
	}
	
	
	

}
