public class demo1
{
public static void main(String a[])
{
	System.out.println("Hello All  javac deo");
}
}