package collection;


public class Faculty {
	public static void main(String[] args) {
		
	
	String name;
	//Array of skills
	
	int a[]=new int[8];
	
	System.out.println(a.length);
	//Sk
}
}