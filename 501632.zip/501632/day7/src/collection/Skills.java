package collection;

public class Skills {
	String name;
	int Exp;
	

}
