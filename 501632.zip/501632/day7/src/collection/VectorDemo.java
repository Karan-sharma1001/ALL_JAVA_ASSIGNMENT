package collection;

import java.util.Vector;

public class VectorDemo {
	public static void main(String[] args) {
		Vector<Integer> v=new Vector<Integer>();
		//Vector v=new Vector();
		v.add(10);
		v.add(22);
		v.add(65);
		
	}

}
