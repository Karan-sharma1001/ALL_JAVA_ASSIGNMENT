package collection;

import java.util.Comparator;
import java.util.HashSet;
import java.util.TreeSet;

public class HashSetDemo {
public static void main(String[] args) {
	
			TreeSet hs=new TreeSet();
			//HashSet hs=new HashSet();
			
			hs.add("Ram");
			hs.add("Shyam");
			hs.add("Karan");
			System.out.println(hs);
			
			
}
}
