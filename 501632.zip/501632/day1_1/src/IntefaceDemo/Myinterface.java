package IntefaceDemo;

public interface Myinterface {
	public void getData() ;
	public void putData();

}
