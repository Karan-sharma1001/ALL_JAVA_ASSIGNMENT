package IntefaceDemo;


public class clinic {
public static void main(String[] args) {
	
	Doctor d =new Doctor();
	d.getData();
	d.putData();	
	
		}
}
