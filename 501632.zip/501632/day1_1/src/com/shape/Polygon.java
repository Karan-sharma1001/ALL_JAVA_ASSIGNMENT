package com.shape;

public interface Polygon {

	public void  calcArea( );
	public void calcPeri( );
	
}
