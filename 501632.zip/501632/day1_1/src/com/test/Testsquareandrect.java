package com.test;

import com.shape.*;



public class Testsquareandrect {

	public static void main(String[] args) {
		

	Rectangle rec=new Rectangle();
	Square squ =new Square();
	rec.calcArea();
	rec.calcPeri();
	squ.calcArea();
	squ.calcPeri();
	
	
}
}