package day1_1;

public class Ointment extends Medicine {

	@Override
	public String displayLabel() {
		super.getDetails();
		System.out.println("In Oinments\n" );
		return null;
	}

}
