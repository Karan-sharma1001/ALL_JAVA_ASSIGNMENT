package day1_1;
import java.util.*;
public class testInher {
public static void main(String[] args) {
	Date d=new Date((2017-1900),2,14);
	//associate a= new associate(10, "Karan",d );
	
	//System.out.println(a);
	ELITian e= new ELITian(23, "Sachin" ,d,2010, "Tus-14");
	
	System.out.println(e);
	}
}
