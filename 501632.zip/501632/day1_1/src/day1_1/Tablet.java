package day1_1;

public class Tablet extends Medicine {

	@Override
	public String displayLabel() {
		super.getDetails();
		System.out.println("store in a cool dry place\n" );
		return null;
	}

}
