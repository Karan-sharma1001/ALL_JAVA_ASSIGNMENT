package day1_1;

public class test {
		public static void main(String a[ ]){
			Student st1=new Student( );
			
			st1.showStud();
			System.out.println(st1.getRollno());
			System.out.println(st1.getName());
			Student st2=new Student(501632,"KARAN ");
			st2.showStud();
			System.out.println(st2.getRollno());
			System.out.println(st2.getName());
}
}
