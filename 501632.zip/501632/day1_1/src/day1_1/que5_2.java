package day1_1;
import java.util.Scanner;
public class que5_2 {

	public static void main(String[] args) {
			
	}

}
