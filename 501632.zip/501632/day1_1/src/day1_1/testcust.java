package day1_1;

public class testcust {
public static void main(String[] args) {
			customer c1=new customer("c101","Raj",6524426);
			customer c2=new customer("c102","Shivi",24426);
			customer c3=new customer("c103","Aish",64426);
			customer c4=new customer("c104","Pooja",65226);
			customer.showCount();
}
}
